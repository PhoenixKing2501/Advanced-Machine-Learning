# Name: Utsav Basu
# Roll No.: 20CS30057
# Programming Assignment 1: GP Regression

# Steps to run the program

1. Install the dependencies using `pip install -r requirements.txt`
2. Make sure the data has this folder structure in the same directory as the notebook:
```
energy+efficiency
├── ENB2012_data
```
3. Open the Jupiter notebook `Utsav_Basu_20CS30057.ipynb` and run all the cells in order.

The report and all plots generated are in the notebook itself. 
